# A megoldások az `index.php` ban találhatóak, röviden lebontva

## 1, 2, 3, 4, 6 feladat látható, az 5-et a dropdown menün keresztül lehet elérni.

## Egyedül az SQL queryk hiányosak.
