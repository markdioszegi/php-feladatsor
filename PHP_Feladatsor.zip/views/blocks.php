<div class="main-block">
  <div class="block">
    <i class=" fab fa-instagram fa-7x"></i>
    <h1>Follow us on Instagram</h1>
  </div>
  <div class="block">
    <i class="fab fa-facebook fa-7x"></i>
    <h1>Follow us on Facebook</h1>
  </div>
  <div class="block">
    <i class="fab fa-twitter fa-7x"></i>
    <h1>Tweet about us</h1>
  </div>
  <div class="block">
    <i class="fab fa-youtube fa-7x"></i>
    <h1>Subscribe on Youtube</h1>
  </div>
</div>