<h1>4. task</h1>
<div class="dropdown">
  <button class="btn btn-dropdown">
    Hover me
  </button>
  <div class="dropdown-menu text-center">
    <a class="dropdown-item" href="#">Go here</a>
    <a class="dropdown-item" href="#">There</a>
    <a class="dropdown-item" href="/index.php?page=blocks">Visit blocks (5. task)</a>
  </div>
</div>